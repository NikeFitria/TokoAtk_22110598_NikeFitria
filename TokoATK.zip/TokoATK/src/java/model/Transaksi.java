/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Dell
 */
public class Transaksi {
    private String kodeBarang, namaPembeli;
    private int jumlah;

    public Transaksi(String kodeBarang, String namaPembeli, int jumlah) {
        this.kodeBarang = kodeBarang;
        this.namaPembeli = namaPembeli;
        this.jumlah = jumlah;
    }

    public String getKodeBarang() { return kodeBarang; }
    public String getNamaPembeli() { return namaPembeli; }
    public int getJumlah() { return jumlah; }

    public void setKodeBarang(String kodeBarang) { this.kodeBarang = kodeBarang; }
    public void setNamaPembeli(String namaPembeli) { this.namaPembeli = namaPembeli; }
    public void setJumlah(int jumlah) { this.jumlah = jumlah; }
}