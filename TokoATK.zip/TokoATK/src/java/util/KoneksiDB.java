/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/**
 *
 * @author Dell
 */

import java.sql.Connection;
import java.sql.DriverManager;

public class KoneksiDB {
    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // untuk MySQL 8+
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/toko_atk", // sesuaikan nama database kamu
                "root", // username MySQL
                ""      // password MySQL (kosong kalau pakai XAMPP default)
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}
